library(shiny)
library(DT)
library(magrittr)
library(tidyverse)
library(lubridate)
library(forecast)
library(seasonal)
library(lubridate)
library(zoo)
library(numDeriv)

ForecastAndMADList = function(d_ts,alpha=0.1){
  train <- window(d_ts, end=c(2003,12))
  ts_empty=ts(rep(NA,(156-length(d_ts))),frequency=12,start=c(end(d_ts)[1],end(d_ts)[2]+1))
  df=data.frame(Demand=as.matrix(d_ts),Year=format(as.Date(as.yearmon(time(d_ts)), format="%d/%m/%Y"),"%Y"),
                Month =  factor(cycle(d_ts), levels = 1:12, labels = month.abb),OneStep=NA,TwoStep=NA,
                RealMAD=NA,EstimatedMAD=NA,Mean=NA,S=NA,Qincoming=NA,Qordered=NA,BeginningInv=NA,EndingInv=NA,BackorderCost=NA,HoldingCost=NA)
  ForecastModel=stlf(log(d_ts))
  df$OneStep=exp(ForecastModel$fitted)
  df$TwoStep=exp(fitted(ForecastModel,h=2))
  df2=data.frame(Demand=as.matrix(ts_empty),Year=format(as.Date(as.yearmon(time(ts_empty)), format="%d/%m/%Y"),"%Y"),
                 Month =  factor(cycle(ts_empty), levels = 1:12, labels = month.abb),OneStep=NA,TwoStep=NA,
                 RealMAD=NA,EstimatedMAD=NA,Mean=NA,S=NA,Qincoming=NA,Qordered=NA,BeginningInv=NA,EndingInv=NA,BackorderCost=NA,HoldingCost=NA)
  df$OneStep=as.numeric(df$OneStep)
  df$TwoStep=as.numeric(df$TwoStep)
  df2$Demand=as.numeric(df2$Demand)
  df=rbind(df,df2)
  df$OneStep[length(d_ts)+1]=exp(forecast(ForecastModel,h=2)$mean[1])
  df$TwoStep[length(d_ts)+2]=exp(forecast(ForecastModel,h=2)$mean[2])
  d_init=ts(d_ts,frequency = 12,start = start(d_ts),end=c(end(d_ts)[1],end(d_ts)[2]-1))
  Forinit=stlf(log(d_init))
  df$TwoStep[length(d_ts)+1]=exp(forecast(Forinit,h=2)$mean[2])
  for(i in (frequency(d_ts)+3):(length(d_ts)-1)){
    df$RealMAD[i+1]=abs((df$OneStep[i]+df$TwoStep[i+1])-(df$Demand[i]+df$Demand[i+1]))
  }
  df$EstimatedMAD[(frequency(d_ts)+4):(length(train))]=mean(df$RealMAD[((frequency(d_ts)+4)):(length(train))])
  for(i in length(train):length(d_ts)){
    df$EstimatedMAD[i+1]=df$EstimatedMAD[i]*alpha+df$RealMAD[i]*(1-alpha)
  }
  df$Sigma= df$EstimatedMAD*1.25
  for(i in (frequency(d_ts)+4):(length(d_ts)+1)){
    df$Mean[i]=df$OneStep[i]+df$TwoStep[i+1]
    Mean=df$Mean[i]
    Sigma=df$Sigma[i]
    f <- function(x) 2*(pnorm(x,Mean,Sigma)-pnorm(0,Mean,Sigma))+pnorm(x,Mean,Sigma)-pnorm(x-90,Mean,Sigma)-90*dnorm(x-90,Mean,Sigma)+3*(pnorm(x,Mean,Sigma)-1)
    df$S[i]=uniroot(f,c(0,Mean+3*Sigma),tol=1)[[1]]
  }
  
  for(i in 120:(length(d_ts))){
    if(i==120){
      df$Qincoming[i+1]=df$TwoStep[i+1]
      df$EndingInv[i]=73
      df$BeginningInv[i+1]=73
      df$Qordered[i]=df$Qincoming[i+1]
      df$Qordered[i+1]=max((df$S[i+1]-df$Qincoming[i+1]-df$BeginningInv[i+1]),0)
    } 
      
    
  }
  return(df)
}

if (interactive()) {
  
  ui <- fluidPage(
    titlePanel("F0rged"),
    sidebarLayout(
      sidebarPanel(fileInput("demanddata", 'Choose file to upload Ten-Year-Demand.csv',
                             accept = c(
                               'text/csv',
                               'text/comma-separated-values',
                               '.csv'
                             )),
                   actionButton("download", "Upload Ten-Year-Demand"),
                   textInput("demand", label="Enter the demand of next month belows", value = "", width = NULL,
                             placeholder = NULL),
                   actionButton("loaddemand", "Click here to enter demand"),
                   actionButton("results", "Show average results")),
      mainPanel(DT::dataTableOutput("first_table"),
                DT::dataTableOutput("second_table"))
    )
  )
  
  server <- function(input, output) {
    observeEvent(input$download,{
      inFile=input$demanddata
      df <- suppressWarnings(read_csv(inFile$datapath,
                                      col_types = cols(
                                        X1 = col_double(),
                                        X2 = col_double(),
                                        x = col_double()
                                      ))) %>% 
        set_names(c("year", "month", "demand")) %>% 
        mutate(year = rep(na.omit(year), each=12),
               month = rep(1:12, 10))
      d_ts <- ts(df$demand,frequency = 12,start = c(1996,1))
      df <- ForecastAndMADList(d_ts)
      counter=120
      assign("counter",counter,envir = .GlobalEnv)
      assign("df",df,envir = .GlobalEnv)
      output$first_table<- renderDataTable({DT::datatable(df[115:148,] %>% select(1,2,3,10,11,12,13,14,15))})
    })
    observeEvent(input$loaddemand,{
      alpha=0.1
      assign("counter",counter,envir = .GlobalEnv)
      d=df$Demand
      counter=sapply(df$Demand, function(x) sum(is.na(x)))
      counter=length(d)-sum(counter)+1
      d <- d[!is.na(d)]
      d[length(d)+1]=as.numeric(input$demand)
      df$Demand[counter]=as.numeric(input$demand)
      d_ts <- ts(d,frequency = 12,start = c(1996,1))
      ForecastModel=stlf(log(d_ts))
      df$OneStep[counter+1]=exp(forecast(ForecastModel,h=2)$mean[1])
      df$TwoStep[counter+2]=exp(forecast(ForecastModel,h=2)$mean[1])
      df$RealMAD[counter]=abs((df$OneStep[counter-1]+df$TwoStep[counter])-(df$Demand[counter-1]+df$Demand[counter]))
      df$EstimatedMAD[counter+1]=df$EstimatedMAD[counter]*alpha+df$RealMAD[counter]*(1-alpha)
      df$Sigma[counter+1]= df$EstimatedMAD[counter+1]*1.25
      df$Mean[counter+1]=df$OneStep[counter+1]+df$TwoStep[counter+2]
      Mean=df$Mean[counter+1]
      Sigma=df$Sigma[counter+1]
      f <- function(x) 2*(pnorm(x,Mean,Sigma)-pnorm(0,Mean,Sigma))+pnorm(x,Mean,Sigma)-pnorm(x-90,Mean,Sigma)-90*dnorm(x-90,Mean,Sigma)+3*(pnorm(x,Mean,Sigma)-1)
      df$S[counter+1]=uniroot(f,c(0,Mean+3*Sigma),tol=1)[[1]]
      df$EndingInv[counter]=df$BeginningInv[counter]+df$Qincoming[counter]-df$Demand[counter]
      df$Qincoming[counter+1]= df$Qordered[counter]
      df$BeginningInv[counter+1]=df$EndingInv[counter]
      df$Qordered[counter+1]=max((df$S[counter+1]-df$Qincoming[counter+1]-df$BeginningInv[counter+1]),0)
      if(df$EndingInv[counter]<0){
        df$BackorderCost[counter]=abs(df$EndingInv[counter])*3
        df$HoldingCost[counter]=0
      } else {
        df$HoldingCost[counter]=abs(df$EndingInv[counter])
        df$BackorderCost[counter]=0
      }
     
      
      assign("df",df,envir = .GlobalEnv)
      output$first_table<- renderDataTable({DT::datatable(df[115:148,] %>% select(1,2,3,10,11,12,13,14,15))})
    })
    observeEvent(input$results,{
      d=data.frame("AverageHoldingCost" = mean(df$HoldingCost[121:144]), "AverageBackorderCost"=mean(df$BackorderCost[121:144]))
      output$second_table<- renderDataTable({DT::datatable(d)})
    })
  }
  
  shinyApp(ui, server)
  
}